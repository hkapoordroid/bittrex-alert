from __future__ import print_function
import logging
from constants import *
import urllib2
import json
import math
from datetime import datetime
import pytz

pst_tz = pytz.timezone('US/Pacific')
logger = logging.getLogger()

def call_api(url):
    resp = urllib2.urlopen(url)
    return json.loads(resp.read())

def median(lst):
    n = len(lst)
    if n < 1:
            return None
    if n % 2 == 1:
            return sorted(lst)[n//2]
    else:
            return sum(sorted(lst)[n//2-1:n//2+1])/2.0

def formatSlackAlertMessage(alert_name, market_name, title, text, color):
    return {
        "attachments": [
        {
            "pretext": alert_name,
            "title": title,
            "title_link": "https://bittrex.com/Market/Index?MarketName="+market_name,
            "text": text,
            "color": color
        }
    ]
}

def formatSlackHealthMessage(text):
    return {
        "text": text, #message you want to send
    }

def calculateIntervalNumber(timestamp, interval_size):
    '''
        this method takes in timestamp (datetime) and returns interval number starting from mid night.
        For example: 1:05 AM and interval size 5 min will return interval 13 since its been 13 5 minute inteval since midnight.
    '''
    d1 = timestamp.replace(hour=0, minute=0, second=0, microsecond=0)
    d2 = timestamp

    return int(math.ceil((d2-d1).total_seconds()/60/interval_size))

def utc_to_pst(input):
    return input.replace(tzinfo=pytz.utc).astimezone(pst_tz)

def convert_bittrex_timestamp_to_datetime(input):
    if "." in input:
        return datetime.strptime(input, '%Y-%m-%dT%H:%M:%S.%f').replace(microsecond=0)
    else:
        return datetime.strptime(input, '%Y-%m-%dT%H:%M:%S')

def get_epoch_time(input):
    epoch = datetime(1970,1,1)
    return (input-epoch).total_seconds()

if __name__ == "__main__":
    #unit test
    #print(datetime.now())
    #print(calculateIntervalNumber(datetime.now(), 5))
    #print(calculateIntervalNumber(datetime.now(), 15))
    #print(utc_to_pst(datetime.strptime('2018-01-06T01:55:44.707', '%Y-%m-%dT%H:%M:%S.%f')))
    print(get_epoch_time(datetime.now()))
